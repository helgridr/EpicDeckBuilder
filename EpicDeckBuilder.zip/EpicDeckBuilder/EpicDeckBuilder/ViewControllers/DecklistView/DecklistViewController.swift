//
//  ViewController.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/7/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit
import CoreData

class DecklistViewController: UIViewController {

    @IBOutlet weak var tableView:UITableView!
    lazy var viewModel = DecklistViewModel(delegate:self)

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Deck"
        //viewModel.loadCurrentDeck()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.loadCurrentDeck()
        print("loaded cards")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func goToSearchView(_ sender: Any) {
        self.performSegue(withIdentifier: "ToSearchView", sender: sender)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        
        switch identifier {
        case "ToDetailView2":
            guard let nextView = segue.destination as? DetailViewController else {return}
            guard let indexPath = self.tableView.indexPathForSelectedRow else {return}
            guard let card = viewModel.cardAt(indexPath) else {return}
            nextView.viewModel.databaseCard = card.info
            nextView.viewModel.cardInDeck = card.inDeck
            self.tableView.deselectRow(at: indexPath, animated: true)
        case "ToSearchView2":
            guard let nextView = segue.destination as? SearchViewController else {return}
            nextView.hollowNavController = true
        case "ToLoadScreen":
            guard let nextView = segue.destination as? DeckLoadViewController else {return}
            nextView.viewModel.currentDeck = viewModel.deckName
        default:
            return
        }
    }

}
extension DecklistViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return viewModel.getTitle(forSection:section)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows(in:section)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: viewModel.getIdentifier(forCellIn:indexPath.section)) else {fatalError("Your cell exploded")}
        viewModel.loadCell(cell, at: indexPath)
        return cell
    }
}
extension DecklistViewController:DecklistViewModelDelegate{
    func reloadTableView(){
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    func presentAlert(_ alert:UIAlertController){
        DispatchQueue.main.async {
            self.present(alert, animated: true)
        }
    }
}


extension DecklistViewController:NavigationalDelegate{
    func jumpToSearchView() {//this needs seems like a shitty way to do this
        self.performSegue(withIdentifier: "ToSearchView2", sender: self)
    }
}
