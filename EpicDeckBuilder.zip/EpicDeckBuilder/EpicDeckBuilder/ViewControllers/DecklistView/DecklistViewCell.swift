//
//  DecklistViewCell.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/11/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
import CoreData
class DecklistViewCell:UITableViewCell{
    @IBOutlet weak var cardName:UILabel!
    @IBOutlet weak var numberOfCopies:UILabel!
    @IBOutlet weak var cardType:UILabel!
    @IBOutlet weak var costSymbol:UIImageView!
    
    func loadCell(card:(inDeck:CardInDeck,info:EpicCard?)){
        self.cardName.text = card.inDeck.name
        self.cardName.adjustsFontSizeToFitWidth = true
        self.cardType.text = card.info?.getTypeLineWithStats()
        self.cardType.adjustsFontSizeToFitWidth = true
        self.numberOfCopies.text = "\(card.inDeck.quantity)x"
        if let cost = card.info?.cost {
            self.costSymbol.image = cost == 1 ? #imageLiteral(resourceName: "one") : #imageLiteral(resourceName: "zero")
        }else{
            self.costSymbol.image = nil
        }
        guard let alignment = card.info?.alignment else{return}
        switch alignment {
        case "EVIL":
            self.backgroundColor = UIColor.red
        case "GOOD":
            self.backgroundColor = UIColor.yellow
        case "WILD":
            self.backgroundColor = UIColor.green
        default:
            self.backgroundColor = UIColor.cyan
        }
    }
}
