//
//  DeckNameCell.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/12/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import  UIKit

class DeckNameCell:UITableViewCell{
    @IBOutlet weak var deckName:UILabel!
    @IBOutlet weak var cardCount:UILabel!
}
