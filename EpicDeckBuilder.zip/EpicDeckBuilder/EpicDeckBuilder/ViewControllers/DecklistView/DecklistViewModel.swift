//
//  DecklistViewModel.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/10/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData
import UIKit


class DecklistViewModel{
    weak var viewController:DecklistViewModelDelegate!
    var deckName:String? = nil
    var eventsInDeck:[(inDeck:CardInDeck,info:EpicCard?)] = []
    var championInDeck:[(inDeck:CardInDeck,info:EpicCard?)] = []
    init(delegate:DecklistViewModelDelegate){
        self.viewController = delegate
    }
    
    func loadCurrentDeck(){
        let userPrefs = UserDefaults.standard
        if let currentDeckName = userPrefs.value(forKey: Constants.kCurrentDeckKey) as? String {
            guard let deck = DatabaseManager.getDeck(named: currentDeckName) else {
                let newDeck =  DatabaseManager.createNewDeck(named: currentDeckName)//create deck if it doesnt exist
                eventsInDeck = []
                championInDeck = []
                deckName = newDeck?.name
                viewController.reloadTableView()
                return
            }
            guard let cards = deck.card?.allObjects as? [CardInDeck] else {return}
            let currentDeck = cards.map{($0,DatabaseManager.searchDatabaseFor(card: $0.name))}
            eventsInDeck = currentDeck.filter{
                $0.1?.type == "EVENT"
            }
            championInDeck = currentDeck.filter{
                $0.1?.type == "CHAMPION"
            }
            deckName = deck.name
            viewController.reloadTableView()
        }else{
            let newDeck =  DatabaseManager.createNewDeck(named: "")//user cant save a deck called empty string
            userPrefs.set("", forKey: Constants.kCurrentDeckKey)
            eventsInDeck = []
            championInDeck = []
            deckName = newDeck?.name
            viewController.reloadTableView()
        }
    }
    func getNumberOfRows(in section:Int)->Int{
        switch section {
        case 0:
            return 1
        case 1:
            return championInDeck.count
        default:
            return eventsInDeck.count
        }
    }
    private func totalNumberOfCards(in list:[(inDeck:CardInDeck,info:EpicCard?)])->Int16{
        return list.map{$0.inDeck.quantity}.reduce(0){$0+$1}
    }
    func getTitle(forSection section:Int)->String?{
        switch section {
        case 0:
            return nil
        case 1:
            let count = totalNumberOfCards(in:championInDeck)
            return count == 0 ? nil : "Champions: \(count)"
        default:
            let count = totalNumberOfCards(in:eventsInDeck)
            return count == 0 ? nil : "Events: \(count)"
        }

    }
    func cardAt(_ indexPath:IndexPath)->(inDeck:CardInDeck,info:EpicCard?)?{
        switch indexPath.section {
        case 0:
            return nil
        case 1:
            return championInDeck[indexPath.row]
        default:
            return eventsInDeck[indexPath.row]
        }

    }
    func getIdentifier(forCellIn section:Int)->String{
        return section == 0 ? "DeckNameCell" : "DecklistCell"
    }
    func loadCell(_ cell:UITableViewCell,at indexPath:IndexPath){
        if indexPath.section == 0{
            guard let cell = cell as? DeckNameCell else {return}
            cell.deckName.text = deckName == "" ? "unsaved deck" : "\"" + (deckName ?? "") + "\""
            cell.deckName.adjustsFontSizeToFitWidth = true
            cell.cardCount.text = "\(totalNumberOfCards(in: championInDeck) + totalNumberOfCards(in: eventsInDeck)) cards"
        }
        else{
            cell.layer.cornerRadius = 10
            guard let cell = cell as? DecklistViewCell else {return}
            guard let card = cardAt(indexPath) else {return}
            cell.loadCell(card: card)
        }
    }
}
