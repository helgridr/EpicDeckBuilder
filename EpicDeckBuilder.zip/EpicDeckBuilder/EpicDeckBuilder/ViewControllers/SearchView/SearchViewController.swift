//
//  SearchViewController.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/9/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class SearchViewController:UIViewController{
    @IBOutlet weak var tableView:UITableView!
    @IBOutlet var tapGestureRecognizer: UITapGestureRecognizer!
    
    lazy var viewModel = SearchViewModel(delegate: self)
    var hollowNavController = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Search"
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyBoardWillAppear(_:)), name: .UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyBoardWillDissapear(_:)), name: .UIKeyboardWillHide, object: nil)
        guard hollowNavController else {return}
        guard let root = self.navigationController?.viewControllers.first as? DecklistViewController else {print("root not found")
            return}
        guard let search = self.navigationController?.viewControllers.last as? SearchViewController else {print("search not found")
            return}
        self.navigationController?.viewControllers = [root,search]
        self.navigationController?.navigationBar.topItem?.title = "Deck"
        hollowNavController = false
            // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tapGestureRecognizer.cancelsTouchesInView = false
        self.tableView.reloadData()
    }

    @objc func keyBoardWillAppear(_ sender: AnyObject){
        //print("keyboard will appear")
        self.tapGestureRecognizer.cancelsTouchesInView = true
    }
    
    @objc func keyBoardWillDissapear(_ sender: AnyObject){
        self.tapGestureRecognizer.cancelsTouchesInView = false
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func goToDecklistView(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func resetFilters(_ sender: Any) {
        viewModel.resetFilters()
    }
    
    @IBAction func dismissKeyboard(_ sender: UITapGestureRecognizer) {
        guard sender.state == UIGestureRecognizerState.ended else {return}
        guard let cell = self.tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? TextFieldCell else{return}
        cell.textField.resignFirstResponder()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        switch identifier {
        case "ToFilterView"://filter by cost is currently broken
            guard let indexPath = self.tableView.indexPathForSelectedRow else {return}
            guard let nextView = segue.destination as? FilterViewController else {return}
            nextView.index = indexPath.row
            nextView.searchViewModel = viewModel
            tableView.deselectRow(at: indexPath, animated: true)
        case "ToResultsView":
            guard let nextView = segue.destination as? ResultsViewController else {return}
            guard let searchText = (self.tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? TextFieldCell)?.textField.text else {print("failed here");return}
            nextView.viewModel.searchString = searchText
            nextView.viewModel.filter = self.viewModel.filter
        default:
            return
        }
    }
}
extension SearchViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows(inSection:section)
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: viewModel.getCellIdentifier(forSection:indexPath.section)) else {fatalError("Your cell exploded")}
        viewModel.loadCell(cell, at:indexPath)
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 2 {
            viewModel.resetFilters()
            self.tableView.deselectRow(at: indexPath, animated: true)
        }
    }
}
extension SearchViewController:SearchViewModelDelegate{
    func setTextField(to string: String?) {
        guard let cell = self.tableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? TextFieldCell else{return}
        cell.textField.text = string
        DispatchQueue.main.async {
            [weak self] in
            self?.tableView.reloadData()
        }
    }
}
extension SearchViewController:UITextFieldDelegate{//set on the storyboard
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let _ = textField.text {
            guard string != "\n" else {
                self.performSegue(withIdentifier: "ToResultsView", sender: self)
                return false}
            return true
        }
        return false
    }
    
}

