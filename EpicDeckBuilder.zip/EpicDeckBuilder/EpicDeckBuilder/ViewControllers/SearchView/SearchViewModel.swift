//
//  SearchViewModel.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/9/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class SearchViewModel{
    weak var viewController:SearchViewModelDelegate!
    
    let filter = FilterState()
    init(delegate:SearchViewModelDelegate) {
        self.viewController = delegate
        
    }
    func resetFilters(){
        filter.states = [[false,false],[false,false,false,false],[false,false],[false,false,false,false,false],[false,false]]
        viewController.setTextField(to: "")
    }

    func getNumberOfRows(inSection section:Int)->Int{
        switch section{
        case 0,2:
            return 1
        default:
            return 5
        }
    }
    
    func getCellIdentifier(forSection section:Int)->String{
        switch section{
        case 0:
            return "TextFieldCell"
        case 1:
            return "FilterCell"
        default:
            return "ResetCell"
        }
    }
    func loadCell(_ cell:UITableViewCell, at indexPath:IndexPath){
        cell.layer.cornerRadius = 10
        switch indexPath.section {
        case 0:
            cell.selectionStyle = .none
        case 1:
            guard let cell = cell as? FilterCell else{return}
            switch indexPath.row{
            case 0:
                cell.filterName.text = filter.categories[indexPath.row]
                let result = filter.names[indexPath.row].enumerated().filter{
                    filter.states[indexPath.row][$0.offset] == true
                    }.map{$0.element}.joined(separator: " or ")
                cell.appliedFilters.text = result
            case 1:
                cell.filterName.text = filter.categories[indexPath.row]
                let result = filter.names[indexPath.row].enumerated().filter{
                    filter.states[indexPath.row][$0.offset] == true
                    }.map{$0.element}.joined(separator: " or ")
                cell.appliedFilters.text = result
            case 2:
                cell.filterName.text = filter.categories[indexPath.row]
                let result = filter.names[indexPath.row].enumerated().filter{
                    filter.states[indexPath.row][$0.offset] == true
                    }.map{$0.element}.joined(separator: " or ")
                cell.appliedFilters.text = result
            case 3:
                cell.filterName.text = filter.categories[indexPath.row]
                let result = filter.names[indexPath.row].enumerated().filter{
                    filter.states[indexPath.row][$0.offset] == true
                    }.map{$0.element}.joined(separator: " or ")
                cell.appliedFilters.text = result
            default:
                cell.filterName.text = filter.categories[indexPath.row]
                let result = filter.names[indexPath.row].enumerated().filter{
                    filter.states[indexPath.row][$0.offset] == true
                    }.map{$0.element}.joined(separator: " or ")
                cell.appliedFilters.text = result
            }
        default:
            cell.textLabel?.text = "Reset Filters"
            cell.textLabel?.textAlignment = .center
            cell.backgroundColor = UIColor.lightGray
        }
     
    }
    

    
}
