//
//  TextFieldCell.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/9/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class TextFieldCell:UITableViewCell{
    @IBOutlet weak var textField:UITextField!
}
