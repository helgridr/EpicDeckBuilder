//
//  DeckLoadViewModel.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/12/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class DeckLoadViewModel{//methods need renaming
    var listOfDecks:[Deck] = []
    var currentDeck:String? = nil
    weak var viewController:DeckLoadViewModelDelegate!
    
    init(delegate: DeckLoadViewModelDelegate) {
        self.viewController = delegate
    }
    
    func getNumberOfSections()->Int{
        return 4
    }
    
    func getNumberOfRows(in section:Int)->Int{
        switch section {
        case 0,1,2:
            return 1
        default:
            return listOfDecks.count
        }
    }
    
    func getSectionHeader(for section:Int)->String?{
        switch section {
        case 0:
            return "Current Deck"
        case 3:
            return "Saved Decks"
        default:
            return nil
        }
    }
    
    func getCellTitle(forCellAt indexPath:IndexPath)->String?{
        return nil
    }
    
    func loadCell(_ cell:UITableViewCell,at indexPath:IndexPath){
        cell.textLabel?.textAlignment = .center
        cell.textLabel?.adjustsFontSizeToFitWidth = true
        cell.layer.cornerRadius = 10
        switch indexPath.section {
        case 0:
            cell.textLabel?.text = currentDeck == "" ? "unsaved deck" : "\"" + (currentDeck ?? "") + "\""
            cell.backgroundColor = UIColor.white
            cell.textLabel?.font = UIFont(name: "Arial", size: 25)
            cell.sizeToFit()
        case 1:
            cell.textLabel?.text = "Save As"
            cell.backgroundColor = UIColor.cyan
            cell.textLabel?.font = UIFont(name: "Arial", size: 17)
            cell.sizeToFit()
        case 2:
            cell.textLabel?.text = "New Deck"
            cell.backgroundColor = UIColor.red
            cell.textLabel?.font = UIFont(name: "Arial", size: 17)
            cell.sizeToFit()
        default:
            cell.textLabel?.text = listOfDecks[indexPath.row].name
            cell.backgroundColor = UIColor.white
            cell.textLabel?.font = UIFont(name: "Arial", size: 17)
            cell.sizeToFit()
        }
    }
    
    func loadDecks(){
        let decks = DatabaseManager.listDecks().filter{
            $0.name != ""
        }
        listOfDecks = decks
        self.viewController.reloadTableView()
    }
    
    func saveDeckToDatabase(){
        let alert = Alerts.createSaveDeckAlert(completion: { [weak self] (string) in
            guard let string = string else {return}
            guard string != "" else{
                let errorAlert = Alerts.createSingleButtonAlert(title: "Error Saving Deck", message: "Please enter a name to save your deck")
                self?.viewController?.presentAlert(errorAlert)
                return
            }
            guard string.count <= 15 else{
                let errorAlert = Alerts.createSingleButtonAlert(title: "Error Saving Deck", message: "Deck name must not be longer than 15 characters")
                self?.viewController?.presentAlert(errorAlert)
                return
            }
            let filteredDeckList = self?.listOfDecks.filter{$0.name == string}
            guard filteredDeckList?.count == 0 else {
                let errorAlert = Alerts.createTwoButtonAlert(title: "Error Saving Deck", message: "A deck with the chosen name already exists.  Do you wish to overwrite it?", completion: {
                    //print("need to implement overwrite")
                    guard let deckToBeDeleted = filteredDeckList?[0] else{
                        let errorAlert = Alerts.createSingleButtonAlert(title: "Error Saving Deck", message: "Deck could not be saved.  Please try again")
                        self?.viewController?.presentAlert(errorAlert)
                        return
                    }
                    guard deckToBeDeleted.name != self?.currentDeck else {return}
                    DatabaseManager.deleteDeck(deck: deckToBeDeleted)
                    guard let newDeck = DatabaseManager.createNewDeck(named: string) else {
                        let errorAlert = Alerts.createSingleButtonAlert(title: "Error Saving Deck", message: "Deck could not be saved.  Please try again")
                        self?.viewController?.presentAlert(errorAlert)
                        return
                    }
                    guard let oldDeck = DatabaseManager.getDeck(named: self?.currentDeck ?? "") else {
                        let errorAlert = Alerts.createSingleButtonAlert(title: "Error Saving Deck", message: "Deck could not be saved.  Please try again")
                        self?.viewController?.presentAlert(errorAlert)
                        return
                    }
                    newDeck.addCards(from: oldDeck)
                    DatabaseManager.saveDeck(deck:newDeck)
                    self?.currentDeck = string
                    let userPrefs = UserDefaults.standard
                    userPrefs.set(string, forKey: Constants.kCurrentDeckKey)
                    self?.loadDecks()
                    
                })
                self?.viewController?.presentAlert(errorAlert)
                return
            }
            guard let oldDeck = DatabaseManager.getDeck(named: self?.currentDeck ?? "") else {
                let errorAlert = Alerts.createSingleButtonAlert(title: "Error Saving Deck", message: "Deck could not be saved.  Please try again")
                self?.viewController?.presentAlert(errorAlert)
                return
            }
            guard oldDeck.name != "" else{
                oldDeck.name = string
                DatabaseManager.saveDeck(deck:oldDeck)
                self?.currentDeck = string
                let userPrefs = UserDefaults.standard
                userPrefs.set(string, forKey: Constants.kCurrentDeckKey)
                self?.loadDecks()
                return
            }
            guard let newDeck = DatabaseManager.createNewDeck(named: string) else {
                let errorAlert = Alerts.createSingleButtonAlert(title: "Error Saving Deck", message: "Deck could not be saved.  Please try again")
                self?.viewController?.presentAlert(errorAlert)
                return
            }
            newDeck.addCards(from: oldDeck)
            DatabaseManager.saveDeck(deck:newDeck)
            self?.currentDeck = string
            let userPrefs = UserDefaults.standard
            userPrefs.set(string, forKey: Constants.kCurrentDeckKey)
            self?.loadDecks()
            
        })
        viewController.presentAlert(alert)
    }
    
    func newDeck(){
        if currentDeck == "" {
            let alert = Alerts.createNewDeckAlert(onNo: {
                [weak self] in
                guard let deck = DatabaseManager.getDeck(named: "")else{return}//
                DatabaseManager.deleteDeck(deck: deck)
                let _ = DatabaseManager.createNewDeck(named: "")
                self?.viewController.dismissView()
                }, onYes: {
                    [weak self] in
                    self?.saveDeckToDatabase()
            })
            self.viewController.presentAlert(alert)
        }else{
            let _ = DatabaseManager.createNewDeck(named: "")
            let userPrefs = UserDefaults.standard
            userPrefs.set("", forKey: Constants.kCurrentDeckKey)
            self.viewController.dismissView()
        }
    }
    
    func loadSavedDeck(at index:Int){
        if currentDeck == "" {
            let alert = Alerts.createNewDeckAlert(onNo: {
                [weak self] in
                guard let deck = DatabaseManager.getDeck(named: "")else{return}
                DatabaseManager.deleteDeck(deck: deck)
                let userPrefs = UserDefaults.standard
                userPrefs.set(self?.listOfDecks[index].name, forKey: Constants.kCurrentDeckKey)
                self?.viewController.dismissView()
                }, onYes: {
                    [weak self] in
                    self?.saveDeckToDatabase()
            })
            self.viewController.presentAlert(alert)
        }else{
            let userPrefs = UserDefaults.standard
            userPrefs.set(self.listOfDecks[index].name, forKey: Constants.kCurrentDeckKey)
            self.viewController.dismissView()
        }
    }
    
    func deleteDeck(at index:Int){
        guard listOfDecks[index].name != currentDeck else{
            let alert = Alerts.createSingleButtonAlert(title: "Error", message: "Deck could not be deleted as it is currently opened")
            self.viewController.presentAlert(alert)
            return
        }
        let alert = Alerts.createTwoButtonAlert(title: "Confirm", message: "Are you sure you want to delete this deck? This process can't be undone") {
            [weak self] in
            guard let deck = self?.listOfDecks[index] else{
                let errorAlert = Alerts.createSingleButtonAlert(title: "Error Deleting Deck", message: "Deck could not be deleted.  Please try again")
                self?.viewController?.presentAlert(errorAlert)
                return
            }
            DatabaseManager.deleteDeck(deck: deck)
            //DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                self?.viewController.reloadTableView()//the delay doesnt seem to help
            //})
            
        }
        self.viewController.presentAlert(alert)
    }
}
