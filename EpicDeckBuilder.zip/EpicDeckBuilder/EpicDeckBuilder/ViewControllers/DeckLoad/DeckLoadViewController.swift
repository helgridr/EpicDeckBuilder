//
//  DeckLoadViewController.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/12/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class DeckLoadViewController:UITableViewController{
    lazy var viewModel = DeckLoadViewModel(delegate: self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.loadDecks()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return viewModel.getNumberOfSections()
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows(in: section)
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.section {
        case 0:
            self.dismiss(animated: true)
        case 1:
            self.viewModel.saveDeckToDatabase()
        case 2:
            self.viewModel.newDeck()
        case 3:
            self.viewModel.loadSavedDeck(at: indexPath.row)
        default:
            break
        }
        self.tableView.deselectRow(at: indexPath, animated: true)
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "LoadCell") else {fatalError("Boom went the cell")}
        viewModel.loadCell(cell, at: indexPath)
        return cell
    }
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        return indexPath.section == 3 ? [UITableViewRowAction(style: .destructive, title: "Delete") { (action, indexPath) in
        self.viewModel.deleteDeck(at: indexPath.row)}] : []
    }
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return viewModel.getSectionHeader(for: section)
    }
}
extension DeckLoadViewController:DeckLoadViewModelDelegate{
    func dismissView() {
        self.dismiss(animated: true)
    }
    
    func reloadTableView(){
        DispatchQueue.main.async {
            [weak self] in
            self?.tableView.reloadData()
        }
    }
    func presentAlert(_ alert:UIAlertController){
        DispatchQueue.main.async {
            [weak self] in
            self?.present(alert, animated: true)
        }
    }
}
