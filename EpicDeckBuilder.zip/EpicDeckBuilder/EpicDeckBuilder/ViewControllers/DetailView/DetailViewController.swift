//
//  ViewController.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/10/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit

//tableview is probably unnecesary
class DetailViewController: UIViewController {

    @IBOutlet weak var tableView:UITableView!
    
    @IBOutlet weak var countLabel: UILabel!
    lazy var viewModel = DetailViewModel(delegate: self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.loadDeck()
        viewModel.loadCardInDeckCard()
        self.navigationItem.title = "Card Details"
        self.tableView.allowsSelection = false
        // Do any additional setup after loading the view.
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewModel.saveChanges()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addOne(_ sender: Any) {
        viewModel.addOneToCount()
    }
    @IBAction func subtractOne(_ sender: Any) {
        viewModel.subtractOneToCount()
    }
    
    @IBAction func goToDecklistView(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func goToSearchView(_ sender: Any) {
        guard let root = self.navigationController?.viewControllers.first as? NavigationalDelegate else {print("root not found")
            return}
        root.jumpToSearchView()
    }
}
extension DetailViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "InfoCell") as? DetailViewInfoCell else {fatalError("Your cell exploded")}
        viewModel.loadCell(cell, at:indexPath)
        return cell
    }
}
extension DetailViewController:DetailViewModelDelegate{
    func reloadTableView(){
        DispatchQueue.main.async {
            [weak self] in
            self?.tableView.reloadData()
            //self?.navigationItem.title = "\(self?.viewModel.results.count) Results"
        }
    }
    func updateLabel(to string: String){
        DispatchQueue.main.async {
            [weak self] in
            self?.countLabel.text = string
        }
    }
}
