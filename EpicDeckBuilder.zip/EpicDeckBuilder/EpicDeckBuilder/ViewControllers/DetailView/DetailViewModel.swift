//
//  DetailViewModel.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/10/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
import CoreData


class DetailViewModel{
    weak var viewController:DetailViewModelDelegate!
    weak var databaseCard:EpicCard?
    weak var deck:Deck?
    var cardInDeck:CardInDeck?
    
    init(delegate:DetailViewModelDelegate){
        self.viewController = delegate
    }
    func loadDeck(){
        if deck == nil{
            let userPrefs = UserDefaults.standard
            if let currentDeckName = userPrefs.value(forKey: Constants.kCurrentDeckKey) as? String {
                deck = DatabaseManager.getDeck(named: currentDeckName)
            }
            else{
                deck = DatabaseManager.getDeck(named: "")
                userPrefs.set("", forKey: Constants.kCurrentDeckKey)
            }
        }
    }
    func loadCardInDeckCard(){
        guard let cardName = databaseCard?.name else {return}
        guard let deck = deck else {return}
        cardInDeck = DatabaseManager.findCard(cardName, inDeck: deck)
        viewController.updateLabel(to: "\(cardInDeck?.quantity ?? 0)")
    }
    
    func addOneToCount(){
        guard let count = cardInDeck?.quantity else {return}
        cardInDeck?.quantity = count + 1
        viewController.updateLabel(to: "\(count + 1)")
    }
    func subtractOneToCount(){
        guard let count = cardInDeck?.quantity else {return}
        guard count > 0 else {return}
        cardInDeck?.quantity = count - 1
        viewController.updateLabel(to: "\(count - 1)")
    }

    func loadCell(_ cell:DetailViewInfoCell, at indexPath:IndexPath){
        cell.loadCell(name: databaseCard?.name, type: databaseCard?.getTypeLine(), cost: databaseCard?.cost, alignment: databaseCard?.alignment, stats: databaseCard?.getStats(), rulesText: databaseCard?.getRelevantText(), set: databaseCard?.getSetLine())

    }
    func saveChanges(){
        guard let cardInDeck = cardInDeck else {print("returned");return}
        guard cardInDeck.quantity > 0 else {
            DatabaseManager.deleteCard(card: cardInDeck)
            print("deleted")
            return
        }
        DatabaseManager.saveCard(card: cardInDeck)
        print("Card saved")
    }

}
