//
//  DetailViewCountCell.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/11/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class DetailViewCountCell: UITableViewCell {
    @IBOutlet weak var count:UILabel!
}
