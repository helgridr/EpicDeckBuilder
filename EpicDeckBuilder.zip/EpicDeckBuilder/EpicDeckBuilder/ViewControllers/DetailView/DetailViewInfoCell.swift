//
//  DetailViewTitleCell.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/10/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class DetailViewInfoCell:UITableViewCell{
    @IBOutlet weak var cardName:UILabel!
    @IBOutlet weak var typeLine:UILabel!
    @IBOutlet weak var stats:UILabel!
    @IBOutlet weak var set:UILabel!
    @IBOutlet weak var rulesText:UILabel!
    @IBOutlet weak var costSymbol:UIImageView!
    @IBOutlet weak var alignmentSymbol:UIImageView!

    
    func loadCell(name:String?,type:String?,cost:Int16?,alignment:String?,stats:String?,rulesText:String?,set:String?){
        self.cardName.text = name
        self.cardName.adjustsFontSizeToFitWidth = true
        self.typeLine.text = type
        self.typeLine.adjustsFontSizeToFitWidth = true
        self.stats.text = stats
        self.rulesText.text = rulesText
        self.set.text = set
        self.set.adjustsFontSizeToFitWidth = true
        self.costSymbol.image = cost == 1 ? #imageLiteral(resourceName: "one") : #imageLiteral(resourceName: "zero")
        guard let alignment = alignment else{return}
        switch alignment {
        case "EVIL":
            self.alignmentSymbol.image = #imageLiteral(resourceName: "evil")
            //self.backgroundColor = UIColor.red
        case "GOOD":
            self.alignmentSymbol.image = #imageLiteral(resourceName: "good")
            //self.backgroundColor = UIColor.yellow
        case "WILD":
            self.alignmentSymbol.image = #imageLiteral(resourceName: "wild")
            //self.backgroundColor = UIColor.green
        default:
            self.alignmentSymbol.image = #imageLiteral(resourceName: "sage")
            //self.backgroundColor = UIColor.cyan
        }
    }
}
