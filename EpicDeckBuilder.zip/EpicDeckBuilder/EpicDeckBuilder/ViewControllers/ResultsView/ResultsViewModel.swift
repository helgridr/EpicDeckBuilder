//
//  File.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/9/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
import CoreData


class ResultsViewModel{
    let viewController:ResultsViewModelDelegate!
    var results:[EpicCard] = []
    weak var filter:FilterState?
    var searchString:String?
    
    init (delegate:ResultsViewModelDelegate){
        self.viewController = delegate
    }
    func getNumberOfRows()->Int{
        return results.count
    }
    func getTitle()->String{
        return "\(results.count) Results"
    }
    func loadCell(_ cell:ResultsViewCell,at index:Int){
        cell.layer.cornerRadius = 10
        cell.loadCell(card: results[index])
    }
    func loadResults(){//this need refactoring
        guard let filter = filter else{return}
        let cost:[Cost] = //[]//searching by cost was crashing the app
        filter.states[0].enumerated().filter{
            $0.element==true
            }.map{switch filter.names[0][$0.offset]{
            case "Zero":
                return Cost.zero
            default:
                return Cost.one
                }
        }//0*/
        let alignment:[Alignment] = filter.states[1].enumerated().filter{
            $0.element==true
            }.map{switch filter.names[1][$0.offset]{
            case "EVIL":
                return Alignment.evil
            case "GOOD":
                return Alignment.good
            case "WILD":
                return Alignment.wild
            default:
                return Alignment.sage
                }
        }
        let types:[CardType] = filter.states[2].enumerated().filter{
            $0.element==true
            }.map{switch filter.names[2][$0.offset]{
            case "CHAMPION":
                return CardType.champion
            default:
                return CardType.event
                }
        }
        let sets:[Sets] = filter.states[3].enumerated().filter{
            $0.element==true
            }.map{switch filter.names[3][$0.offset]{
            case "Set 1":
                return Sets.setOne
            case "Tyrants":
                return Sets.tyrants
            case "Uprising":
                return Sets.uprising
            case "Kickstarter Promo":
                return Sets.kickstarterPromo
            default:
                return Sets.seasonOnePromo
                }
        }
        let rarity:[CardRarity] = filter.states[4].enumerated().filter{
            $0.element==true
            }.map{switch filter.names[4][$0.offset]{
            case "Common":
                return CardRarity.common
            default:
                return CardRarity.rare
                }
        }
        self.results = DatabaseManager.searchDatabase(for: searchString, withCost: cost, withAlignment: alignment, withType: types, withRarity: rarity, fromSet: sets)
        
    }
}
