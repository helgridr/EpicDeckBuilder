//
//  ResultsViewCell.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/10/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class ResultsViewCell:UITableViewCell{
    @IBOutlet weak var cardName:UILabel!
    @IBOutlet weak var cardType:UILabel!
    @IBOutlet weak var costSymbol:UIImageView!
    
    func loadCell(name:String?,type:String?,cost:Int16,alignment:String?){
        self.cardName.text = name
        self.cardType.text = type
        self.costSymbol.image = cost == 1 ? #imageLiteral(resourceName: "one") : #imageLiteral(resourceName: "zero")
        guard let alignment = alignment else{return}
        switch alignment {
        case "EVIL":
            self.backgroundColor = UIColor.red
        case "GOOD":
            self.backgroundColor = UIColor.yellow
        case "WILD":
            self.backgroundColor = UIColor.green
        default:
            self.backgroundColor = UIColor.cyan
        }
    }
    func loadCell(card:EpicCard){
        self.cardName.text = card.name
        self.cardName.adjustsFontSizeToFitWidth = true
        self.cardType.text = card.getTypeLineWithStats()
        self.cardName.adjustsFontSizeToFitWidth = true
        self.costSymbol.image = card.cost == 1 ? #imageLiteral(resourceName: "one") : #imageLiteral(resourceName: "zero")
        guard let alignment = card.alignment else{return}
        switch alignment {
        case "EVIL":
            self.backgroundColor = UIColor.red
        case "GOOD":
            self.backgroundColor = UIColor.yellow
        case "WILD":
            self.backgroundColor = UIColor.green
        default:
            self.backgroundColor = UIColor.cyan
        }
    }
}
