//
//  ResultsViewController.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/9/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit
import CoreData

class ResultsViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    lazy var viewModel = ResultsViewModel(delegate:self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.viewModel.loadResults()
        
        self.navigationItem.title = "\(self.viewModel.results.count) Results"
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        guard let indexPath = self.tableView.indexPathForSelectedRow else {return}
        switch identifier {
        case "ToDetailView":
            guard let nextView = segue.destination as? DetailViewController else {return}
            nextView.viewModel.databaseCard = self.viewModel.results[indexPath.row]
            self.tableView.deselectRow(at: indexPath, animated: true)
        default:
            return
        }
    }

    @IBAction func goToDecklistView(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func goToSearchView(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension ResultsViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows()
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "ResultsViewCell") as? ResultsViewCell else {fatalError("Your cell exploded")}
        viewModel.loadCell(cell, at:indexPath.row)
        //cell.textLabel?.text = viewModel.getNameForItem(at: indexPath.row)
        return cell//not implemented
    }
}
extension ResultsViewController:ResultsViewModelDelegate{
    func reloadTableView(){
        DispatchQueue.main.async {
            [weak self] in
            self?.tableView.reloadData()
            self?.navigationItem.title = "\(self?.viewModel.results.count ?? 0) Results"
        }
    }
}
