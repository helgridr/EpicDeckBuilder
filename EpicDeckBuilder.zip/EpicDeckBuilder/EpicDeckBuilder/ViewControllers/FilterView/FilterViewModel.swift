//
//  FilterViewModel.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/9/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
/*
protocol filterViewModelDelegate:class{
    
}
class filterViewModel {
    weak var viewController:filterViewModelDelegate!
    init(delegate:filterViewModelDelegate){
        self.viewController = delegate
    }
}
*/
