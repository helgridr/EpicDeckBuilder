//
//  FilterViewController.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/9/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit

//this needs refactoring
class FilterViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    //lazy var viewModel = filterViewModel(delegate:self)
    
    weak var searchViewModel:SearchViewModel?
    var index:Int?
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = searchViewModel?.filter.categories[index ?? 0]
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func goToDecklistViw(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func goToSearchView(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension FilterViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchViewModel?.filter.states[index ?? 0].count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "FilterViewCell") as? FilterViewCell else {fatalError("Your cell exploded")}
        //viewModel.loadCell(cell, at:indexPath)
        cell.checkMark.image = searchViewModel?.filter.states[index ?? 0][indexPath.row] == false ? nil : #imageLiteral(resourceName: "checkmark")
        cell.selectionStyle = .none
        cell.filterName.text = searchViewModel?.filter.names[index ?? 0][indexPath.row]
        cell.layer.cornerRadius = 10
        return cell//not implemented
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //tableView.deselectRow(at: indexPath, animated: <#T##Bool#>)
        searchViewModel?.filter.states[index ?? 0][indexPath.row] = !((searchViewModel?.filter.states[index ?? 0][indexPath.row]) ?? false)
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        
    }
}
/*
extension FilterViewController:filterViewModelDelegate{
    
}*/
