//
//  Alerts.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/12/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
class Alerts{
    static func createSingleButtonAlert(title: String, message:String,completion:(()->())? = nil)->UIAlertController{
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "ok", style: .default){
            alert in
            completion?()
        }
        alert.addAction(ok)
        return alert
    }
    static func createTwoButtonAlert(title:String,message:String,completion:(()->())? = nil)->UIAlertController{
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        if let _ = completion {
            let no = UIAlertAction(title: "cancel", style: .cancel)
            
            alert.addAction(no)
        }
        
        let ok = UIAlertAction(title: "confirm", style: .default){
            alert in
            completion?()
        }
        alert.addAction(ok)
        
        return alert
    }
    static func createSaveDeckAlert(completion:@escaping ((String?)->()))->UIAlertController{
        let alert = UIAlertController(title: "Save Deck", message:"Please enter a unique name for your deck",preferredStyle: .alert)
        alert.addTextField { (textField) in textField.placeholder = "Deckname.dec"
        }
        let save = UIAlertAction(title: "Save", style: .default) {
            (action) in
            guard let name = alert.textFields?[0].text else {
                completion(nil)
                return}
            completion(name)
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel)
        alert.addAction(save)
        alert.addAction(cancel)
        return alert
    }
    static func createNewDeckAlert(onNo:@escaping (()->()),onYes:@escaping (()->()))->UIAlertController{
        let alert = UIAlertController(title: "Unsaved Deck", message: "Your current deck is not saved. Would you like to save it?", preferredStyle: .alert)
        let no = UIAlertAction(title: "discard", style: .cancel){
            alert in
            onNo()
        }
        alert.addAction(no)
        let ok = UIAlertAction(title: "save", style: .default){
            alert in
            onYes()
        }
        alert.addAction(ok)
        return alert
    }
}
