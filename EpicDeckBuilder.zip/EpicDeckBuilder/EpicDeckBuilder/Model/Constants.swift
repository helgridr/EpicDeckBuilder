//
//  Constants.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/7/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

class Constants{
    static let kJsonUrl = "https://raw.githubusercontent.com/helgridr/EpicDeckBuilder/master/epicjson.json"
    //.jpeg
    static let kKickstarterPromosBaseUrl = "http://www.epiccardgame.com/wp-content/uploads/2015/09/"
    static let kTyrantsBaseUrl = "http://www.epiccardgame.com/wp-content/uploads/2016/03/"
    static let kBaseSetBaseUrl = "http://www.epiccardgame.com/wp-content/uploads/2015/09/"//season one promos are also here
    //.png
    static let kUprisingBaseUrl = "https://raw.githubusercontent.com/helgridr/EpicDeckBuilder/master/Images/"
    
    static let kCurrentDeckKey = "com.EpicDeckBuilder.GodohaldoPerez.CurrentDeck"
    //static let kFilterStateKey = "com.EpicDeckBuilder.GodohaldoPerez.FilterState"
    //static let kSearchStringKey = "com.EpicDeckBuilder.GodohaldoPerez.SearchString"
}
