//
//  ErrorEnums.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/7/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
//these all need axpansion
enum DBError:Error{
    case error
}
enum NetworkError:Error{
    case error
}
enum JsonParserError:Error{
    case error
}
