//
//  Deck.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/10/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData

class Deck:NSManagedObject{
    func addCards(from deck:Deck){
        guard let context = self.managedObjectContext else {return}
        deck.card?.forEach{
            guard let oldCard = $0 as? CardInDeck else{return}
            let newCard = CardInDeck(context: context)
            newCard.copyAttributes(from:oldCard )
            self.addToCard(newCard)
        }
    }
}
