//
//  Networking.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/7/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

enum NetworkCallType{
    case getJson
    
    func getUrl()->String{
        switch self{
        case .getJson:
            return Constants.kJsonUrl
        }
    }
}

class Networking{
    static func callNetwork(to callType:NetworkCallType,completion:@escaping(Any?,Error?)->()){
        switch callType {
        case .getJson:
            getJson(url: callType.getUrl(), completion: completion)
        }
        
    }
    private static func getJson(url:String,completion:@escaping(Any?,Error?)->()){
        guard let myUrl = URL(string:url)else{
            let networkError = NetworkError.error
            completion(nil,networkError)
            return
        }
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.error
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.error
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.error
                completion(nil,networkError)
                return
            }
            guard let data = data else {
                let networkError = NetworkError.error
                completion(nil,networkError)
                return
            }
            do{
                let jsonDecoder = JSONDecoder()
                let database = try jsonDecoder.decode(EpicCardDatabase.self, from: data)
                completion(database,nil)
            }
            catch{
                completion(nil,JsonParserError.error)
                return
            }
        }
        task.resume()
    }
}
