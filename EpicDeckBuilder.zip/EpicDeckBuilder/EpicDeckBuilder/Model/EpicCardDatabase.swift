//
//  myCardDatabase.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/7/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
struct EpicCardDatabase:Codable{
    let date:String
    let cards:[Card]
}
//MARK:Card
struct Card:Codable{
    let name:String
    let cost:Cost
    let alignment:Alignment
    let type:CardType
    let offense:Int?
    let defense:Int?
    let rulesText:String?
    let flavorText:String?
    let discardPileText:String?
    let subtype:String?
    let cubeRarity:CardRarity
    let artistName:String
    let set:Sets
    enum CodingKeys: String,CodingKey{
        case name
        case cost
        case alignment
        case type
        case offense
        case defense
        case rulesText = "rules_text"
        case flavorText = "flavor_text"
        case discardPileText = "discard_pile_text"
        case subtype
        case cubeRarity = "cube_rarity"
        case artistName = "artist_name"
        case set
    }
    
}
//MARK:Card Enums
enum CardType:String,Codable{
    case champion = "CHAMPION"
    case event = "EVENT"
    
    func getPredicate()->NSPredicate{
        return NSPredicate(format: "type = %@", self.rawValue)
    }
}
enum Alignment:String,Codable{
    case evil = "EVIL"
    case wild = "WILD"
    case sage = "SAGE"
    case good = "GOOD"
    
    func getPredicate()->NSPredicate{
        return NSPredicate(format: "alignment = %@", self.rawValue)
    }
}
enum Cost:Int16,Codable{
    case zero = 0
    case one = 1
    
    func getPredicate()->NSPredicate{
        return NSPredicate(format: "cost = %d", self.rawValue)
    }
}
enum Sets:String,Codable{
    case kickstarterPromo = "Kickstarter Promo"
    case tyrants = "Tyrants"
    case setOne = "Set 1"
    case seasonOnePromo = "Season 1 Promo"
    case uprising = "Uprising"
    
    func getPredicate()->NSPredicate{
        return NSPredicate(format: "set = %@", self.rawValue)
    }
}
enum CardRarity:String,Codable{
    case common = "Common"
    case rare = "Rare"
    
    func getPredicate()->NSPredicate{
        return NSPredicate(format: "rarity = %@", self.rawValue)
    }
}



