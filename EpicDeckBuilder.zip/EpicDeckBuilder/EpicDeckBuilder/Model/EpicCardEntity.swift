//
//  EpicCard.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/8/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData

class EpicCard:NSManagedObject{
    func load(_ card: Card){
        self.name = card.name
        self.cost = Int16(card.cost.rawValue)
        self.alignment = card.alignment.rawValue
        self.type = card.type.rawValue
        self.offense = card.offense != nil ? Int16(card.offense!) : -1//magic value
        self.defense = card.defense != nil ? Int16(card.defense!) : -1//magic value
        self.rulesText = card.rulesText
        self.flavorText = card.flavorText
        self.discardPileText = card.discardPileText
        self.subtype = card.subtype
        self.rarity = card.cubeRarity.rawValue
        self.artistName = card.artistName
        self.set = card.set.rawValue
    }
    func getTypeLine()->String{
        let mySubType = self.subtype ?? ""
        let myAlignment = self.alignment ?? ""
        let myType = self.type ?? ""
        return mySubType == "" ? [myAlignment, myType].joined(separator: " ") : [myAlignment, mySubType, myType].joined(separator: " ")
    }
    func getTypeLineWithStats()->String{
        let mySubType = self.subtype ?? ""
        let myAlignment = self.alignment ?? ""
        let myType = self.type ?? ""
        return myType == "EVENT" ? (mySubType == "" ? [myAlignment, myType].joined(separator: " ") : [myAlignment, mySubType, myType].joined(separator: " ")) : [myAlignment, mySubType, myType, "(\(self.offense)/\(self.defense))"].joined(separator: " ")
    }
    func getSetLine()->String{
        return (self.set ?? "") + " " + (self.rarity ?? "")
    }
    func getRelevantText()->String{
        var rulestext = ""
        if let rules = self.rulesText {
            rulestext += rules 
        }
        if let graveText = self.discardPileText {
            rulestext += rulestext == "" ? "" : "\n\n"
            rulestext += "Discard pile text:\n" + graveText
        }
        return rulestext
    }
    func getStats()->String{
        return self.offense != -1 ? "\(offense)/\(defense)" : ""
    }
    
}

