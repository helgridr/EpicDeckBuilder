//
//  FilterState.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/10/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

class FilterState{
    var states:[[Bool]] = [[false,false],[false,false,false,false],[false,false],[false,false,false,false,false],[false,false]]
    let names:[[String]] = [["Zero","One"],["EVIL","GOOD","WILD","SAGE"],["CHAMPION","EVENT"],["Set 1","Tyrants","Uprising","Kickstarter Promo","Season 1 Promo"],["Common","Rare"]]
    let categories = ["Cost:","Alignment:","Type:","Set:","Rarity:"]
    
    /*init() {//broken
        let userPrefs = UserDefaults.standard
        guard let filterState = userPrefs.value(forKey: Constants.kFilterStateKey) as? [[Bool]] else{return}
        self.states = filterState
    }
    deinit {
        let userPrefs = UserDefaults.standard
        userPrefs.set(self.states, forKey: Constants.kFilterStateKey)
    }*/
}
