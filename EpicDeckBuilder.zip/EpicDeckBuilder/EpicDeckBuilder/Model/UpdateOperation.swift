//
//  UpdateOperation.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/16/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
class UpdateOperation:Operation{
    private var working = false {
        willSet {
            willChangeValue(forKey: "isExecuting")
        }
        didSet {
            didChangeValue(forKey: "isExecuting")
        }
    }
    override var isExecuting: Bool {
        get{
            return working
        }
        set{
            working = newValue
        }
    }
    private var done = false {
        willSet {
            willChangeValue(forKey: "isFinished")
        }
        
        didSet {
            didChangeValue(forKey: "isFinished")
        }
    }
    override var isFinished: Bool {
        get{
            return done
        }
        set{
            done = newValue
        }
    }
    //kvo stuff
   
    override func main(){
        guard isCancelled == false else {
            isFinished = true
            return
        }
        isExecuting = true
        print ("does this work?")
        guard let database = DatabaseManager.getDatabase() else{
            Networking.callNetwork(to: .getJson, completion: { (newDatabase, error) in
                guard error == nil else {
                    //this takes forever to go off. might consider setting a timer
                    print("Unable to find a card database and unable to load one from through the network")
                    self.isExecuting = false
                    self.isFinished = true
                    return
                    //fatalError("no network conection or existing database")
                }
                guard let newDatabase = newDatabase as? EpicCardDatabase else{
                    print("Unable to find a card database and unable to load one from through the network")
                    self.isExecuting = false
                    self.isFinished = true
                    return
                    //fatalError("failure to load new database with no existing database")
                }
                
                DatabaseManager.loadNewDatabase(database: newDatabase){
                    self.isExecuting = false
                    self.isFinished = true
                }
            })
            return
        }
        print("found old database")
        Networking.callNetwork(to: .getJson) { (newDatabase, error) in
            print("network call returned")
            guard error == nil else {
                print("error checking for updates")
                self.isExecuting = false
                self.isFinished = true
                return}
            guard let newDatabase = newDatabase as? EpicCardDatabase else{
                print("error checking for updates")
                self.isExecuting = false
                self.isFinished = true
                return}
            guard let currentDatabaseDate = database.date else {
                print("no date on current database")
                self.isExecuting = false
                self.isFinished = true
                return
            }
            if currentDatabaseDate != newDatabase.date{
                print("updated database")
              //  DispatchQueue.main.async {
                    DatabaseManager.deleteDatabase(database: database)
                    DatabaseManager.loadNewDatabase(database: newDatabase){
                        self.isExecuting = false
                        self.isFinished = true
                   }
            //    }
                
            }else{
                print("database didn't need updating")
                self.isExecuting = false
                self.isFinished = true
            }
            
            
        }
    }

    
    //succeded and fail
    
}
