//
//  DatabaseManager.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/7/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData
class DatabaseManager{
    static func getDatabase()->CardDatabase?{
        guard let context = AppDelegate.viewContext else{return nil}
        let fetchRequest:NSFetchRequest<CardDatabase> = CardDatabase.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "date", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        do {
            let databases = try context.fetch(fetchRequest)
            let count = databases.count
            switch count {
            case 0:
                return nil
            case 1:
                return databases[0]
            default:
                databases.enumerated().forEach{
                    if $0.offset != 0{
                        deleteDatabase(database: $0.element)
                    }
                }
                return databases[0]
            }
        } catch{
            return nil
        }
    }
    
    static func loadNewDatabase(database:EpicCardDatabase,completion:()->()){
        guard let context = AppDelegate.viewContext else{return}//some sort of error popup to try again?
        let newDatabase = CardDatabase(context: context)
        newDatabase.date = database.date
        database.cards.forEach{card in
            let newCard = EpicCard(context: context)
            newCard.load(card)
            newDatabase.addToResults(newCard)
        }
        do{
            try context.save()
        } catch let error {
            print("\(error)")//some sort of error popup
        }
        completion()
    }

    //input text might be "" because of text field, might neet to sanitize input
    static func searchDatabase(for text:String? = nil, withCost cost:[Cost], withAlignment alignment:[Alignment], withType type:[CardType], withRarity rarity:[CardRarity], fromSet set:[Sets])->[EpicCard]{
        guard let context = AppDelegate.viewContext else{return []}
        let fetchRequest:NSFetchRequest<EpicCard> = EpicCard.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true, selector: #selector(NSString.localizedStandardCompare(_:)))
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        //build predicates
        var andPredicateArray:[NSPredicate] = []
        if let text = text{//search name, rules text and discard pile text for the given text
            if text != ""{
                let predicate = NSPredicate(format: "name contains[c] %@ || rulesText contains[c] %@ || discardPileText contains[c] %@", text, text, text)
                andPredicateArray.append(predicate)
            }
        }
        if !cost.isEmpty{
            let orPredicateArray = cost.map{$0.getPredicate()}
            andPredicateArray.append(NSCompoundPredicate(orPredicateWithSubpredicates: orPredicateArray))
        }
        if !alignment.isEmpty{
            let orPredicateArray = alignment.map{$0.getPredicate()}
            andPredicateArray.append(NSCompoundPredicate(orPredicateWithSubpredicates: orPredicateArray))
        }
        if !type.isEmpty{
            let orPredicateArray = type.map{$0.getPredicate()}
            andPredicateArray.append(NSCompoundPredicate(orPredicateWithSubpredicates: orPredicateArray))
        }
        if !rarity.isEmpty{
            let orPredicateArray = rarity.map{$0.getPredicate()}
            andPredicateArray.append(NSCompoundPredicate(orPredicateWithSubpredicates: orPredicateArray))
        }
        if !set.isEmpty{
            let orPredicateArray = set.map{$0.getPredicate()}
            andPredicateArray.append(NSCompoundPredicate(orPredicateWithSubpredicates: orPredicateArray))
        }
        if !andPredicateArray.isEmpty {
            let predicate = NSCompoundPredicate(andPredicateWithSubpredicates: andPredicateArray)
            fetchRequest.predicate = predicate
        }
        
        //perform search
        do{
            let results = try context.fetch(fetchRequest)
            return results
        }
        catch let error{
            print(error)
            return []//make the return optional and return nil here?
        }
        
    }
    static func searchDatabaseFor(card name:String?)->EpicCard?{
        guard let context = AppDelegate.viewContext else{return nil}
        let fetchRequest:NSFetchRequest<EpicCard> = EpicCard.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true, selector: #selector(NSString.localizedStandardCompare(_:)))
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        guard let name = name else{return nil}
        let predicate = NSPredicate(format: "name = %@", name)
        fetchRequest.predicate = predicate
        do{
            let results = try context.fetch(fetchRequest)
            return results.isEmpty ? nil : results[0]
        }
        catch let error{
            print(error)
            return nil//make the return optional and return nil here?
        }
        
    }
    
    static func deleteDatabase(database:CardDatabase){
        guard let context = database.managedObjectContext else {return}
        context.delete(database)

        do {

            try context.save()
        } catch let error {
            print("\(error)")
        }
    }
    
    static func getDeck(named:String)->Deck?{
        guard let context = AppDelegate.viewContext else{return nil}
        let fetchRequest:NSFetchRequest<Deck> = Deck.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        let predicate = NSPredicate(format: "name = %@", named)
        fetchRequest.predicate = predicate
        do {
            let deck = try context.fetch(fetchRequest)
            //let count = deck.count
            switch deck.count {
            case 0:
                return nil
            case 1:
                return deck[0]
            default:
                deck.enumerated().forEach{
                    if $0.offset != 0{
                        deleteDeck(deck: $0.element)
                    }
                }
                return deck[0]
            }
        } catch{
            return nil
        }
    }
    static func listDecks()->[Deck]{
        guard let context = AppDelegate.viewContext else{return []}
        let fetchRequest:NSFetchRequest<Deck> = Deck.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        //let predicate = NSPredicate(format: "name = %@", named)
        //fetchRequest.predicate = predicate
        do {
            let decks = try context.fetch(fetchRequest)
            return decks
        }catch{
            return []
        }
    }
    static func createNewDeck(named:String)->Deck?{//need to do a collision check here starting at new deck 1
        guard let context = AppDelegate.viewContext else{return nil}//some sort of error popup to try again?
        let newDeck = Deck(context: context)
        newDeck.name = named
        do{
            try context.save()
            return newDeck
        } catch let error {
            print("\(error)")//some sort of error popup
            return nil
        }
    }
    static func findCard(_ card:String,inDeck deck:Deck)->CardInDeck?{
        guard let context = deck.managedObjectContext else {return nil}
        let fetchRequest:NSFetchRequest<CardInDeck> = CardInDeck.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        fetchRequest.sortDescriptors = [sortDescriptor]
        let predicate = NSPredicate(format: "name = %@", card)
        fetchRequest.predicate = predicate
        do {
            let foundCard = try context.fetch(fetchRequest)
            //let count = deck.count
            switch foundCard.count {
            case 0:
                let newCard = CardInDeck(context: context)
                newCard.name = card
                newCard.quantity = 0
                deck.addToCard(newCard)
                try context.save()
                return newCard
            case 1:
                return foundCard[0]
            default:
                foundCard.enumerated().forEach{
                    if $0.offset != 0{
                        deleteCard(card:$0.element)
                    }
                }
                return foundCard[0]
            }
        } catch{
            return nil
        }
    }
    static func deleteDeck(deck:Deck){
        guard let context = deck.managedObjectContext else {return}
        context.delete(deck)
        do {
            
            try context.save()
        } catch let error {
            print("\(error)")
        }
    }
    static func deleteCard(card:CardInDeck){
        guard let context = card.managedObjectContext else {return}
        context.delete(card)
        
        do {
            
            try context.save()
        } catch let error {
            print("\(error)")
        }
    }
    static func saveCard(card:CardInDeck){
        guard let context = card.managedObjectContext else {return}
        do {
            
            try context.save()
        } catch let error {
            print("\(error)")
        }
    }
    static func saveDeck(deck:Deck){
        guard let context = deck.managedObjectContext else {return}
        do {
            try context.save()
        } catch let error {
            print("\(error)")
        }
    }
}
