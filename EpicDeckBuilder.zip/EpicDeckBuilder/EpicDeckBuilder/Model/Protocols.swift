//
//  VMProtocols.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/7/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData
import UIKit

//MARK DecklistViewModelDelegate
protocol DecklistViewModelDelegate:class{
    func reloadTableView()
    func presentAlert(_ alert:UIAlertController)
}

//MARK SearchViewModelDelegate
protocol SearchViewModelDelegate:class{
    func setTextField(to string:String?)
}

//MARK ResultsViewModelDelegate
protocol ResultsViewModelDelegate:class {
    func reloadTableView()
}

//MARK DetailViewModelDelegate
protocol DetailViewModelDelegate:class {
    func reloadTableView()
    func updateLabel(to string: String)
}

//MARK DeckLoadViewModelDelegate
protocol DeckLoadViewModelDelegate:class{
    func reloadTableView()
    func presentAlert(_ alert:UIAlertController)
    func dismissView()
}
//MARK NavigationalDelegate
protocol NavigationalDelegate{
    func jumpToSearchView()
}
