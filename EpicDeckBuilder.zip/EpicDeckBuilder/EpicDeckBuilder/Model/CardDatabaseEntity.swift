//
//  CardDatabase.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/8/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData

class CardDatabase:NSManagedObject{
    
}
