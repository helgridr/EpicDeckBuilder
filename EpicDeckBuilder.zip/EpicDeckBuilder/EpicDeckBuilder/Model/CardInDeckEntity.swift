//
//  CardInDeck.swift
//  EpicDeckBuilder
//
//  Created by Godohaldo Perez on 10/10/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData

class CardInDeck:NSManagedObject{
    func copyAttributes(from card:CardInDeck){
        self.quantity = card.quantity
        self.name = card.name
    }
}
